<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require './phpmailer/src/Exception.php';
require './phpmailer/src/PHPMailer.php';
require './phpmailer/src/SMTP.php';
require './config/SMTP.php';
require './function/functions.php';

$openMail = false;
$subject = "";
$body ="";
 if(isset($_POST['form-one'])){
  $subject = "Bima Rahisi site";
  $_POST['Product']='Personal Cover';
  $_POST['Sub_product'] = 'Single Cover';
  $body ="<!DOCTYPE html>
  <html>
  <head>
      <link href='https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i' rel='stylesheet'>
      <link rel='stylesheet' href='https://bimarahisi.ke/assets/vendor/bootstrap/css/bootstrap.min.css'>
  </head>
  <body>
      <div style='background-color: rgb(67, 67, 245); margin:1rem' class='container-sm p-4'>
          <div style='background-color: rgb(227, 232, 240);  width:80%; margin:1rem auto;  padding:1rem;' class='container-sm p-3'>
          <hr>
              <div class='margin-auto p-4'>
                  <a href='https://bimarahisi.ke/' target='_blank' rel='noopener noreferrer'>
                  <img style='width: 55%;' src='https://bimarahisi.ke/images/img/logo3.png' alt='bimarahisi logo'></a>
              </div>
              <hr>
              <b><p>Hey !,</p></b>
              <b><p>{$_POST['Full_name']} has registered for {$_POST['Product']} -  {$_POST['Sub_product']}</p></b>
              <div>
                  <p><a href='https://bimarahisi.ke/' target='_blank' rel='noopener noreferrer'>bimarahisi.ke</a></p>
              </div>
          </div>
      </div>
  </body>
  </html>";
  to_csv($body);
  $openMail = true;
 }
 else if(isset($_POST['form-two'])){
  $subject = "Bima Rahisi site";
  $_POST['Product']='Group Personal Cover';
  $_POST['Sub_product'] = 'Group Cover';
  $body ="<!DOCTYPE html>
  <html>
  <head>
      <link href='https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i' rel='stylesheet'>
      <link rel='stylesheet' href='https://bimarahisi.ke/assets/vendor/bootstrap/css/bootstrap.min.css'>
  </head>
  <body>
      <div style='background-color: rgb(67, 67, 245); margin:1rem' class='container-sm p-4'>
          <div style='background-color: rgb(227, 232, 240);  width:80%; margin:1rem auto;  padding:1rem;' class='container-sm p-3'>
          <hr>
              <div class='margin-auto p-4'>
                  <a href='https://bimarahisi.ke/' target='_blank' rel='noopener noreferrer'>
                  <img style='width: 55%;' src='https://bimarahisi.ke/images/img/logo3.png' alt='bimarahisi logo'></a>
              </div>
              <hr>
              <b><p>Hey !,</p></b>
              <b><p>{$_POST['Full_name']} has registered for {$_POST['Product']} -  {$_POST['Sub_product']}</p></b>
              <div>
                  <p><a href='https://bimarahisi.ke/' target='_blank' rel='noopener noreferrer'>bimarahisi.ke</a></p>
              </div>
          </div>
      </div>
  </body>
  </html>";
  to_csv($body);
  $openMail = true;
 }
 if($openMail){
  $mail = new PHPMailer(true);
  $mail->isSMTP();
  $mail->Host =$my_smtp;
  $mail->SMTPAuth = $smtp_auth;
  $mail->Username =$my_username;
  $mail->Password = $my_password;
  $mail->SMTPSecure =$smtp_secure;
  $mail->Port =$port;
  $mail->setFrom($my_username);
  $mail->addAddress($send_to);
  $mail->isHTML(true);
  $mail->Subject = $subject;
  $mail->Body = $body;
  $mail->addAttachment("web_data/data.csv",'test');
  $mail->send();
  echo"<script> document.location.href='thankyou.html';</script>";
  exit;
 
 
}
?>
<!DOCTYPE html>
<html lang="en">

<!-- header -->
<?php include 'include/header.php';?>

<!--end header -->

<body>

  <!-- ======= Top Bar ======= -->
  <section id="topbar" class="d-flex align-items-center">
    <div class="container d-flex justify-content-center justify-content-md-between">
      <div class="contact-info d-flex align-items-center">
        <i class="bi bi-envelope d-flex align-items-center"><a href="mailto:info.ke@bimarahisi.com">info.ke@bimarahisi.com</a></i>
        <i class="bi bi-phone d-flex align-items-center ms-4"><span>+2547 03065065</span></i>
      </div>

      <div class="cta d-none d-md-flex align-items-center">
        <a href="./index.php" class="scrollto">Get a Quote</a>
      </div>
    </div>
  </section>

  <!-- ======= Header ======= -->
 <?php include 'include/navbar.php';?>
  <!-- End Header -->
  <!-- ======= about Header ======= -->
  <header style="height: 90px;" id="heder" class="d-flex align-items-center bg-dark">
    <div class="container d-flex align-items-center justify-content-between">
      <div class="about-nav">
        <span><a href="./policy.html">Conduct</a></span>
        <span><a href="./policy.html">Terms</a></span>
        <span><a href="./policy.html">Policies</a></span>
      </div>

      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="nav-link scrollto text-white" href="/">Home</a></li>
          <li><a class="nav-link scrollto active" href="#">Personal and Group </a></li>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

    </div>
  </header><!-- End Header -->
<style>
  
</style>

<section id="form-design">
  <div class="container">
    <div class="row row-rev">
      <div class="col-lg-4">
        <div class="form-info d-flex flex-column justify-content-center align-items-center">
          <div class="icon d-flex justify-content-center align-items-center mb-2">
            <i class='bx bx-heart'></i>
          </div>
          <div class="title text-white my-2">Personal Cover</div>
          <span style="text-align: center;color:rgb(238, 232, 232)">
            The Personal Accident cover provides a financial back up in the event of injuries or death resulting from an accident. Peace of Mind Life has its risks and some are unavoidable. The resulting financial strain can be minimized with the Personal Accident Cover. Get peace of mind for you and your loved ones.
Accidental Death Benefit, Temporal Total Disability Benefit, Permanent Total Disability Benefit and Last Expense Benefit
          </span>
        </div>
      </div>
      <div class="col-lg-8">
       
        <div class="form-con d-flex flex-column">
          <div class="tab-con d-flex my-2">
            <div class="nav-tab d-flex float-right">
              <div onclick="activeTab('one','Personal Accident Cover')" class="tab  d-flex align-items-center justify-content-center tab-one py-1 form-tab-active">
                Personal
              </div>
              <div onclick="activeTab('two','Group Accident Cover')"  class="tab d-flex align-items-center justify-content-center tab-two py-1">
                Group
              </div>
              <div onclick="activeTab('three','Other')"  class="tab d-flex align-items-center justify-content-center tab-three py-1">
               
              </div>
            </div>
          </div>
         <div class="form-title my-2">
          <b class="t">Personal Accident Cover</b>
         </div>
         <!-- form one -->
          <form class="form-one" action="" method="post">
            <div class="row">
              <div class="col-md-6">
                <input placeholder="Full Name" name="Full_name" class="form-control form-one-input" type="text" required>
              </div>
              <div class="col-md-6">
                <input class="form-control form-one-input" name="Phone_number" placeholder="Phone number" type="text" required>
              </div>
             
            </div>
            <div class="row my-3">
              <div class="col-md-6">
                <input placeholder="email" name="email" class="form-control form-one-input" type="email" required>
              </div>
              <div class="col-md-6">
                <input placeholder="ID no" name="ID_number" class="form-control form-one-input" type="number" required>
              </div>
             
            </div>
            <div class="row my-3">
              <div class="col-md-6">
                <input placeholder="Date of Birth" name="DoB" class="form-control form-one-input" type="date" required>
              </div>
            
             
            </div>

     <!--pupup  -->
     <div style="display: flex; position: fixed; left: 0;" class="box-model box-model-closed">
  <div class="model">
    <span onclick="closeModel(0)" id="close-model">&times;</span>
      <div class="quote-title f-title">
        <h2>Choose a Payment Method</h2>
      </div>
      <div class="quote-form">
     
        <select class="form-control" name="payment_sub" id="quote-select">
          <option value="0">--Choose--</option>
          <option value="M-PESA">M-PESA</option>
          
        </select>
        <div class="msg"></div>
        <div class="number-field wow fadeInUp">
        <span class="lb">Number</span>
        
        <input class="form-control" type="number" name="payment_number" required>
      </div>

      </div>
      <div class="quote-btn">

        <input type="submit" value="submit" name="form-one" class="button buttn bt">
        
      </div>
  
  
  </div>
  
</div>
<!-- end popup -->

            <button onclick="formValid()" type="button" style="border-radius: 50px;" class="btn btn-primary px-5 py-1 my-2 pop">Submit</button>
          </form>
          <!-- second form -->
          <form class="form-two" action="" method="post">
            <div class="row">
              <div class="col-md-6">
                <input placeholder="Organization" class="form-control form-two-input" type="text" name="Full_name" required>
              </div>
              <div class="col-md-6">
                <input class="form-control form-two-input" placeholder="Phone number" type="text" name="Phone_number" required>
              </div>
             
            </div>
            <div class="row my-3">
              <div class="col-md-6">
                <input placeholder="email" name="email" class="form-control form-two-input" type="text" required>
              </div>
              <div class="col-md-6">
                <input name="No_of_employees/Farmers" placeholder="No of Employees" class="form-control form-two-input" type="text" required>
              </div>
             
            </div>
                 <!--pupup  -->
                 <div style="display: flex; position: fixed; left: 0;" class="box-model box-model-closed">
  <div class="model">
    <span onclick="closeModel(1)" id="close-model">&times;</span>
      <div class="quote-title f-title">
        <h2>Choose a Payment Method</h2>
      </div>
      <div class="quote-form">
     
        <select class="form-control" name="payment_sub" id="quote-select">
          <option value="0">--Choose--</option>
          <option value="M-PESA">M-PESA</option>
         
        </select>
        <div class="msg"></div>
        <div class="number-field wow fadeInUp">
        <span class="lb">Number</span>
        
        <input class="form-control" type="number" name="payment_number" required>
      </div>

      </div>
      <div class="quote-btn">

        <input type="submit" value="submit" name="form-two" class="button buttn bt">
        
      </div>
  
  
  </div>
  
</div>
<!-- end popup -->
           
            <button onclick="formTwoValid()" type="button" style="border-radius: 50px;" class="btn btn-primary px-5 py-1 my-2 pop">Submit</button>
          </form>
          <!-- third form -->
          <form class="form-three" action="" method="post">
            <!-- Third form here
             -->
             <center>unavailable at the Moment</center>
          </form>
        </div>
      </div>
    </div>
  </div>
</section>

  <!-- ======= Footer ======= -->
 <?php include 'include/footer.php';?>
  <!-- End Footer -->
  <script src='assets/js/form3.js'></script>
  <script>
// form-one
let formOneInput = document.querySelectorAll(".form-one-input");
let close = document.querySelectorAll('#close-model');
let boxModel = document.querySelectorAll('.box-model');
function formValid(){
  let filled =[];
  for(let i =0; i<formOneInput.length;i++){
    if(formOneInput[i].value != ""){
      filled.push(formOneInput[i]);
    }
    else{
      formOneInput[i].className="form-control is-invalid";
    }
  }
  filled.length == formOneInput.length && boxModel[0].classList.add('box-model-open');
}


function closeModel(no){
  boxModel[no].classList.remove('box-model-open')
}



// form two
let formTwoInput = document.querySelectorAll(".form-two-input");
function formTwoValid(){
  let filled =[];
  for(let i =0; i<formTwoInput.length;i++){
    if(formTwoInput[i].value != ""){
      filled.push(formTwoInput[i]);
    }
    else{
      formTwoInput[i].className="form-control is-invalid";
    }
  }
  filled.length == formTwoInput.length && boxModel[1].classList.add('box-model-open');
}

// form three
let formThreeInput = document.querySelectorAll(".form-three-input");
function formThreeValid(){
  let filled =[];
  for(let i =0; i<formThreeInput.length;i++){
    if(formThreeInput[i].value != ""){
      filled.push(formThreeInput[i]);
    }
    else{
      formThreeInput[i].className="form-control is-invalid";
    }
  }
  filled.length == formThreeInput.length && boxModel[2].classList.add('box-model-open');

}
</script>
</body>

</html>