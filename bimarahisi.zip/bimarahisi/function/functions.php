<?php
function to_csv($arry=[]){
    $header = ['Product','Sub_product','Full_name','Phone_number','Nationality','ID_number','email','DoB','Name_of_Child','No_of_Children','No_of_Adults','From','To','Departure_Date','Return_date','With_spouse','Car/Bike_Make','Car/Bike_Model','Car/Bike_RegNo','Year_of_Manufacture','Estimate_value','No_of_employees/Farmers','Crop_to_be_insured','Acre_age'];
    if(file_exists('web_data/data.csv')){
        $fh = fopen("web_data/data.csv","ab");
        $data = [];
        for ($i = 0; $i < count($header); $i++){
            if(array_key_exists($header[$i],$_POST)){
                    array_push($data,$_POST["$header[$i]"]);
            }else{
                array_push($data," ");
            }  
        }
        fputcsv($fh,$data);
        fclose($fh);
    }else{
        $fh = fopen("web_data/data.csv","wb");
        fputcsv($fh,$header); //this write All products headers to a csv
        $data = [];
        for ($i = 0; $i < count($header); $i++){
            if(array_key_exists($header[$i],$_POST)){
                    array_push($data,$_POST["$header[$i]"]);
            }else{
                array_push($data," ");
            }  
        }
        fputcsv($fh,$data);
        fclose($fh);
    }
}
?>