<?php
include "include/phpmail.php";
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'include/phpmailer/src/Exception.php';
require 'include/phpmailer/src/PHPMailer.php';
require 'include/phpmailer/src/SMTP.php';
$myBody ="name {$_POST['name']} {$_POST['message']}";
$openMail = false;
 if(isset($_POST["send"])){
    $mail = new PHPMailer(true);

    $mail->isSMTP();
    $mail->Host ='smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username =$my_username;
    $mail->Password = $my_password;
    $mail->SMTPSecure ='ssl';
    $mail->Port = 465;
    $mail->setFrom("bismarquemomanyi@gmail.com");
    $mail->addAddress($my_username);
    $mail->isHTML(true);
    $mail->Subject = $_POST["email"];
    $mail->Body = $myBody;
    $mail->send();
    header('Location:thankyou.html', true, 303);
    exit;
    

 }

?>