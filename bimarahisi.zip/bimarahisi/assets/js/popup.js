let msg = document.querySelector('.msg');
let pagename = location.pathname

// let boxModel = document.querySelector('.box-model');
  let list = document.querySelector('.bt');
  let select = document.querySelector('#quote');
  list.addEventListener('click',()=>{
    if(select.value!=0){
      let pagename = select.value;
      let path = `${pagename}`
    location.href=path;
    }
    else{
      msg.style.color = "red";
      msg.innerHTML = '*Please select a product'
      select.classList.add('input-shake')
    }
  })
//


  // =======================================
  
  let label = document.querySelectorAll('.lb');
  let selec = document.querySelectorAll('#quote-select')
  let bt = document.querySelectorAll(".bt");
  let number_field = document.querySelectorAll('.number-field');
  for(let i = 0;i<selec.length;i++){
    selec[i].addEventListener('change',()=>{
      console.log("done")
      let value = selec.value;
      if(value != 0){
        number_field[i].style.display ='block';
        number_field[i].style.animationName ='fadeInUp';
        number_field[i].style.visibility ='visible';

        label[i].innerHTML = `Please Enter mobile Number`;
  
      }else{
        number_field.style.display ='none';
        number_field.style.visibility ='hidden';
      }
  
    });
  }
 