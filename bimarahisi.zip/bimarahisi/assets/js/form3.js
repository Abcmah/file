  let formOne = document.querySelector(".form-one");
  let title = document.querySelector(".t");
  let formTwo = document.querySelector(".form-two");
  let formThree = document.querySelector(".form-three");
  let tabOne = document.querySelector(".tab-one");
  let tabTwo = document.querySelector(".tab-two");
  let tabThree = document.querySelector(".tab-three");
 

  const activeTab =(tab,ti)=>{
if(tab==="one"){
  title.innerHTML=ti;
  tabOne.className="tab  d-flex align-items-center justify-content-center tab-one py-1 form-tab-active";
  tabTwo.className="tab  d-flex align-items-center justify-content-center tab-one py-1";
  tabThree.className="tab  d-flex align-items-center justify-content-center tab-one py-1";
  formOne.style.display ="block";
  formTwo.style.display ="none";
  formThree.style.display ="none";
  console.log("one")
}
else if(tab==="two"){
  title.innerHTML=ti;
  tabOne.className="tab  d-flex align-items-center justify-content-center tab-one py-1";
  tabTwo.className="tab  d-flex align-items-center justify-content-center tab-one py-1 form-tab-active";
  tabThree.className="tab  d-flex align-items-center justify-content-center tab-one py-1";
  formOne.style.display ="none"
  formTwo.style.display ="block"
  formThree.style.display ="none"
  console.log("two")
}
else if(tab==="three"){
  title.innerHTML=ti;
  tabOne.className="tab  d-flex align-items-center justify-content-center tab-one py-1";
  tabTwo.className="tab  d-flex align-items-center justify-content-center tab-one py-1";
  tabThree.className="tab  d-flex align-items-center justify-content-center tab-one py-1 form-tab-active";
  
  formOne.style.display ="none"
  formTwo.style.display ="none"
  formThree.style.display ="block"
  console.log("ttree")
}
}
