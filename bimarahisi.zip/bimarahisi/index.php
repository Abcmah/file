<?php 
date_default_timezone_set('Africa/Nairobi');

$current_time = date('H:i:s');
$target_time = '11:44:00';
print($current_time);
if ($current_time == $target_time) {
   print_r('done');
}
?>
<!DOCTYPE html>
<html lang="en">

<?php include 'include/header.php'; ?>

<body>

  <!-- ======= Top Bar ======= -->
  <section id="topbar" class="d-flex align-items-center">
    <div class="container d-flex justify-content-center justify-content-md-between">
      <div class="contact-info d-flex align-items-center">
        <i class="bi bi-envelope d-flex align-items-center"><a href="mailto:info.ke@bimarahisi.com">info.ke@bimarahisi.com</a></i>
        <i class="bi bi-phone d-flex align-items-center ms-4"><span>+2547 03065065</span></i>
      </div>

      <div class="cta d-none d-md-flex align-items-center">
        <a href="./motorinsurance.php" class="scrollto">Get Motor Quote</a>
      </div>
    </div>
  </section>

  <!-- ======= Header ======= -->
<?php include 'include/navbar.php'; ?>
  <!-- End Header -->

  <!-- ======= Hero Section ======= -->
  <section id="hero" class="d-flex">
    <div class="container d-flex justify-content-end" data-aos="fade-in">
      <div style="align-self: center;" class="d-flex align-items-center">
        <i class="bx bxs-right-arrow-alt get-started-icon"></i>
        <a href="./motorinsurance.php" class="btn-get-started scrollto op">Get Motor Quote</a>
      </div>
    </div>
  </section><!-- End Hero -->


   <!-- popup -->
 <div class="box-model box-model-closed">
  <div class="model">
    <span id="close-model">&times;</span>
      <div class="quote-title">
        <h2>Choose a Product</h2>
      </div>
      <div class="quote-form">
        <select class="form-control" name="quotes" id="quote">
          <option value="0">--Choose--</option>
          <option value="motorinsurance.php">Motor Insurance</option>
          <option value="travel.php">Travel Insurance</option>
          <option value="healthcover.php">Health Cover</option>
          <option value="personal.php">Personal Cover</option>
          <option value="student.php">Student Cover</option>
          <option value="internal.php">Internal travel</option>
          <option value="educateprotect.php">Educate protect</option>
          <option value="hospitalcash.php">Hospital cash</option>
          <option value="agric.php">Agricultural Cover</option>
          <option value="allproducts.php">All Products</option>
        </select>
        <div class="msg"></div>
      </div>
      <div class="quote-btn">
        <button type="submit" class="button buttn bt">Submit</button>
      </div>
  
  
  </div>
</div>
<!-- end popup -->

  <main id="main">

    <!-- ======= Why Us Section ======= -->
    <section id="why-us" class="why-us">
      <div class="container">

        <div class="row">
          <div class="col-xl-4 col-lg-5" data-aos="fade-up">
            <div class="content">
              <h3>Why Us</h3>
              <p>
                 ‘Bima Rahisi- Easy Insurance- Kenya Based, Mobile Insurance. All our products are ordered, Fulfilled and paid for via your mobile phone- Fast, Easy, Affordable and Trustworthy <br>– BIMA RAHISI
              </p>
              <div class="text-center">
                <a href="./motorinsurance.php" class="more-btn">Get Started <i class="bx bx-chevron-right"></i></a>
              </div>
            </div>
          </div>
          <div class="col-xl-8 col-lg-7 d-flex">
            <div class="icon-boxes d-flex flex-column justify-content-center">
              <div class="row">
                <div class="col-xl-4 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="100">
                  <div class="icon-box mt-4 mt-xl-0">
                    <i class="bx bx-time"></i>
                    <h4>Fast</h4>
                    <p>We process Insurance within 10 minutes <b>24/7</b></p>
                  </div>
                </div>
                <!-- <div class="col-xl-4 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="200">
                  <div class="icon-box mt-4 mt-xl-0">
                    <i class="bx bx-"></i>
                    <h4>Ullamco laboris ladore pan</h4>
                    <p>Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt</p>
                  </div>
                </div> -->
                <div class="col-xl-4 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="300">
                  <div class="icon-box mt-4 mt-xl-0">
                    <i class='bx bx-check-shield'></i>
                    <h4>Easy</h4>
                    <p>Processing insurance  with  us  is easy, just  dial *409#</p>
                  </div>
                </div>
         <div class="col-xl-4 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="300">
                  <div class="icon-box mt-4 mt-xl-0">
                    <i class='bx bx-check-shield'></i>
                    <h4>Affordable</h4>
                    <p>All our insurance covers are  cheap and  reliable</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

      </div>
    </section><!-- End Why Us Section -->

    <!-- ======= About Section ======= -->

    <!-- End About Section -->


       <!-- ======= Products Section ======= -->
<section id="services" class="services section-bg">
  <div class="container">

    <div class="section-title" data-aos="fade-up">
      <h2>Our Products</h2>
      <p>Travel Insurance, Motor Insurance, Health Insurance & Micro Insurance (Hospital cash, Educate Protect, Internal Travel and Student Insurance)</p>
    </div>

    <div class="row">
      <div class="col-lg-4 col-md-6" data-aos="fade-up">
        <div class="icon-box">
          <div class="icon-title">
            <svg  version="1.1" id="product-icon" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 viewBox="0 0 389.734 389.734" style="enable-background:new 0 0 389.734 389.734;" xml:space="preserve">
<path d="M79.888,259.335c0,4.971-4.029,9-9,9H25.057c-4.971,0-9-4.029-9-9c0-4.971,4.029-9,9-9h45.832
	C75.859,250.335,79.888,254.364,79.888,259.335z M82.246,216.923c-0.521,0.093-1.049,0.139-1.576,0.139s-1.055-0.046-1.576-0.139
	c-21.848-3.887-41.858-15.436-56.346-32.521C8.079,167.103,0,145.146,0,122.576V67.214c0-7.404,4.718-17.773,27.194-25.121
	c14.415-4.712,33.406-7.308,53.475-7.308c20.067,0,39.058,2.596,53.473,7.308c22.477,7.348,27.195,17.717,27.195,25.121
	c0,0.055,0,0.109-0.001,0.164v55.197c0,22.57-8.078,44.527-22.747,61.826C124.102,201.487,104.092,213.037,82.246,216.923z
	 M143.336,122.576v-55.18c-1.782-4.252-22.617-14.61-62.667-14.61C40.608,52.786,19.773,63.15,18,67.399v55.177
	c0,37.243,26.258,69.09,62.669,76.328C117.079,191.666,143.336,159.819,143.336,122.576z M70.888,282.659H50.393
	c-4.971,0-9,4.029-9,9s4.029,9,9,9h20.495c4.971,0,9-4.029,9-9S75.859,282.659,70.888,282.659z M266.999,312.491
	c0,4.971-4.029,9-9,9h-51.963c-4.139,19.104-21.173,33.457-41.498,33.457c-20.843,0-38.226-15.097-41.789-34.93
	c-7.212-2.285-13.161-7.098-16.358-13.518c-1.6-3.223-2.408-6.637-2.408-10.158V236.33c0-4.971,4.029-9,9-9s9,4.029,9,9v60.013
	c0,0.72,0.177,1.441,0.526,2.145c0.305,0.612,0.76,1.234,1.353,1.822c5.249-17.491,21.498-30.272,40.676-30.272
	c20.323,0,37.357,14.354,41.497,33.454h51.963C262.97,303.491,266.999,307.52,266.999,312.491z M188.996,312.492
	c0-13.484-10.971-24.455-24.457-24.455c-13.418,0-24.348,10.861-24.456,24.255c0.002,0.111,0.001,0.224,0,0.336
	c0.073,13.423,11.016,24.32,24.456,24.32C178.024,336.948,188.996,325.977,188.996,312.492z M389.695,277.168l-0.026,5.813
	c-0.018,3.771-0.038,8.07-0.038,13.362c0,10.763-7.741,20.082-18.654,23.626c-3.542,19.856-20.937,34.979-41.797,34.979
	c-23.411,0-42.457-19.046-42.457-42.456s19.046-42.455,42.457-42.455c19.148,0,35.377,12.743,40.651,30.192
	c1.128-1.144,1.8-2.492,1.8-3.887c0-5.325,0.021-9.652,0.038-13.447l0.026-5.809c0.033-7.179,0.077-17.011-0.027-21.6
	c-0.074-3.287-0.163-5.984-0.394-8.317H232.819c-3.23,0-10.794,0-33.942-22.876c-7.052-6.97-21.071-21.8-23.651-28.047
	c-1.897-4.594,0.289-9.856,4.883-11.754c4.524-1.868,9.696,0.223,11.665,4.674c1.223,2.193,8.543,11.172,19.151,21.725
	c13.361,13.291,20.46,17.595,22.395,18.278H361.16c-2.894-2.775-6.606-6.064-11.376-10.291c-2.477-2.194-5.198-4.605-8.186-7.287
	c-2.18-1.955-4.352-4.031-6.453-6.038c-3.059-2.923-6.222-5.944-9.515-8.703c-2.906-2.436-5.658-4.752-8.276-6.956
	c-33.401-28.124-42.379-35.683-70.547-35.683h-62.132c-4.971,0-9-4.029-9-9s4.029-9,9-9h62.132
	c34.737,0,48.614,11.685,82.141,39.913c2.606,2.194,5.347,4.502,8.241,6.927c3.744,3.137,7.123,6.365,10.391,9.487
	c2.093,1.999,4.069,3.888,6.04,5.655c2.958,2.654,5.65,5.04,8.102,7.212c21.571,19.112,27.369,24.249,27.943,49.674
	C389.773,259.913,389.73,269.48,389.695,277.168z M353.636,312.399c-0.051-13.441-11.002-24.362-24.457-24.362
	c-13.485,0-24.457,10.971-24.457,24.455c0,13.485,10.971,24.456,24.457,24.456c13.479,0,24.446-10.961,24.457-24.438
	C353.636,312.473,353.636,312.436,353.636,312.399z M329.191,303.492h-0.023c-4.971,0-8.988,4.029-8.988,9s4.041,9,9.012,9
	s9-4.029,9-9S334.162,303.492,329.191,303.492z M149.254,238.168c0,4.971,4.029,9,9,9h10.125c4.971,0,9-4.029,9-9s-4.029-9-9-9
	h-10.125C153.284,229.168,149.254,233.197,149.254,238.168z M164.55,303.492h-0.027c-4.971,0-8.987,4.029-8.987,9s4.043,9,9.014,9
	s9-4.029,9-9S169.521,303.492,164.55,303.492z"/>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
</svg>
          </div>
          <h4 class="title"><a href="./motorinsurance.php">Motor Insurance</a></h4>
          <p class="description">Car insurance ensures that you do not suffer a setback /break the bank financially in case of an accident. But remember, it is not a one-size-fits-all requirement.</p>
        </div>
      </div>
      
    </div>




  
  <div  class="box">
        <div style="margin:auto;" >
          <button class="btn btn-info px-4 py-3 pop">Other Insurance</button>
        </div>
      </div>
</section><!-- End Services Section --> 
   <!-- ======= Clients Section ======= -->
<section id="clients" class="clients">
  <div class="container" data-aos="fade-up">
    <div class="section-header">
      <center><h3>Our Clients</h3></center>
      
    
    </div>
    <div class="clients-slider swiper-container">
      <div class="swiper-wrapper align-items-center">
        <div class="swiper-slide"><img src="assets/img/clients/client-1.png" class="img-fluid" alt=""></div>
        <div class="swiper-slide"><img src="assets/img/clients/client-2.jpeg" class="img-fluid" alt=""></div>
        <div class="swiper-slide"><img src="assets/img/clients/client-3.jpg" class="img-fluid" alt=""></div>
        <div class="swiper-slide"><img src="assets/img/clients/client-4.jpg" class="img-fluid" alt=""></div>
        <div class="swiper-slide"><img src="assets/img/clients/client-5.png" class="img-fluid" alt=""></div>
        <div class="swiper-slide"><img src="assets/img/clients/client-6.png" class="img-fluid" alt=""></div>
        <div class="swiper-slide"><img src="assets/img/clients/client-7.jpeg" class="img-fluid" alt=""></div>
        <div class="swiper-slide"><img src="assets/img/clients/client-8.png" class="img-fluid" alt=""></div>
      </div>
      <div class="swiper-pagination"></div>
    </div>

  </div>
</section><!-- End Clients Section -->

<!-- our partner -->
<section id="clients" class="section-bg">

  <div class="container">

    <div class="section-header">
      <center><h3 class="my-3">Our Partners</h3></center>
      
    
    </div>

    <div class="row no-gutters clients-wrap clearfix wow fadeInUp" style=" animation-name: none;">

      <div class="col-lg-3 col-md-4 col-xs-6">
        <div class="client-logo">
         <a href="https://bimarahisi.ke/" target="_blank"> <img src="assets/img/partners/client-20.png" class="img-fluid" alt=""></a>
        </div>
      </div>
      
      <div class="col-lg-3 col-md-4 col-xs-6">
        <div class="client-logo">
          <a href="https://bimarahisi.ke/" target="_blank"><img src="assets/img/partners/client-21.png" class="img-fluid" alt=""></a>
        </div>
      </div>
    
      <div class="col-lg-3 col-md-4 col-xs-6">
        <div class="client-logo">
         <a href="https://bimarahisi.ke/" target="_blank"> <img src="assets/img/partners/client-22.png" class="img-fluid" alt=""></a>
        </div>
      </div>
      
      <div class="col-lg-3 col-md-4 col-xs-6">
        <div class="client-logo">
          <img src="assets/img/partners/client-24.png" class="img-fluid" alt="">
        </div>
      </div>
    
      <div class="col-lg-3 col-md-4 col-xs-6">
        <div class="client-logo">
          <img src="assets/img/partners/client-25.png" class="img-fluid" alt="">
        </div>
      </div>
      
      <div class="col-lg-3 col-md-4 col-xs-6">
        <div class="client-logo">
          <img src="assets/img/partners/client-26.png" class="img-fluid" alt="">
        </div>
      </div>
      
      <div class="col-lg-3 col-md-4 col-xs-6">
        <div class="client-logo">
          <img src="assets/img/partners/client-27.png" class="img-fluid" alt="">
        </div>
      </div>
      <div class="col-lg-3 col-md-4 col-xs-6">
        <div class="client-logo"><a href="https://www.uapoldmutual.com/" target="_blank">
          <img src="assets/img/partners/image-30.jpg" class="img-fluid" alt=""></a>
        </div>
      </div>
      <div class="col-lg-3 col-md-4 col-xs-6">
        <div class="client-logo"><a href="https://bimarahisi.ke/#" target="_blank">
          <img src="assets/img/partners/apa.png" class="img-fluid" alt=""></a>
        </div>
      </div>

    </div>

  </div>
 

</section>
<!-- end our partner -->

   

    <!-- ======= Contact Section ======= -->
    <section id="contact" class="contact">
      <div class="container">

        <div class="section-title">
          <h2 data-aos="fade-up">Contact</h2>
          <p data-aos="fade-up">You can get to us via</p>
        </div>

        <div class="row justify-content-center">

          <div class="col-xl-3 col-lg-4 mt-4" data-aos="fade-up">
            <div class="info-box">
              <i class="bx bx-map"></i>
              <h3>Our Address</h3>
              <p>Kileleshwa, Nairobi, Kenya</p>
            </div>
          </div>

          <div class="col-xl-3 col-lg-4 mt-4" data-aos="fade-up" data-aos-delay="100">
            <div class="info-box">
              <i class="bx bx-envelope"></i>
              <h3>Email Us</h3>
              <p>info.ke@bimarahisi.com</p>
            </div>
          </div>
          <div class="col-xl-3 col-lg-4 mt-4" data-aos="fade-up" data-aos-delay="200">
            <div class="info-box">
              <i class="bx bx-phone-call"></i>
              <h3>Call Us</h3>
              <p>+254 7030 65065</p>
            </div>
          </div>
        </div>

        <div class="row justify-content-center" data-aos="fade-up" data-aos-delay="300">
          <div class="col-xl-9 col-lg-12 mt-4">
            <form action="forms/contact.php" method="post" role="form" class="php-email-form">
              <div class="row">
                <div class="col-md-6 form-group">
                  <input type="text" name="name" class="form-control" id="name" placeholder="Your Name" required>
                </div>
                <div class="col-md-6 form-group mt-3 mt-md-0">
                  <input type="email" class="form-control" name="email" id="email" placeholder="Your Email" required>
                </div>
              </div>
              <div class="form-group mt-3">
                <input type="text" class="form-control" name="subject" id="subject" placeholder="Subject" required>
              </div>
              <div class="form-group mt-3">
                <textarea class="form-control" name="message" rows="5" placeholder="Message" required></textarea>
              </div>
              <div class="my-3">
                <div class="loading">Loading</div>
                <div class="error-message"></div>
                <div class="sent-message">Your message has been sent. Thank you!</div>
              </div>
              <div class="text-center"><button type="submit">Send Message</button></div>
            </form>
          </div>

        </div>

      </div>
    </section><!-- End Contact Section -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <?php include 'include/footer.php';?>
  <!-- End Footer -->
<script>
  // openning model
let close = document.querySelector('#close-model');
let boxModel = document.querySelector('.box-model');
let btngetquote = document.querySelectorAll('.pop');

// btngetquote.addEventListener('click',()=>{
//      boxModel.classList.add('box-model-open')
// })

for(let i=0;i<btngetquote.length;i++){
  btngetquote[i].addEventListener('click',()=>{
    boxModel.classList.add('box-model-open');
  })
}

close.addEventListener('click',()=>{
    boxModel.classList.remove('box-model-open')
})
let page = document.querySelector('.mobile-nav-overly')
let menu = document.querySelector('#menu')
let menupressed = false;
let menuClose = document.querySelector('.closeee');
menu.addEventListener('click',()=>{
  menu.style.display='none';
  menuClose.style.display ='block';
})
menuClose.addEventListener('click',(e)=>{
    menu.style.display='block';
    menuClose.style.display ='none';
    console.log(e.target.length)
})
page.addEventListener('click',()=>{
  menu.style.display='block';
    menuClose.style.display ='none';
})
document.addEventListener('click',()=>{
  if(page.style.display=='none'){
    menu.style.display='block';
    menuClose.style.display ='none';
  }
})
</script>
  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <!-- <script src="assets/vendor/aos/aos.js"></script> -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>
  <script src="assets/js/popup.js"></script>

</body>

</html>