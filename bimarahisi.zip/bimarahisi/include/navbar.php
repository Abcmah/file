<header id="header" class="d-flex align-items-center">
    <div class="container d-flex align-items-center justify-content-between">

      <div class="logo">
        <a href="index.html"><img src="./images/img/logo3.png" alt="" class="img-fluid"></a>
      </div>

      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="nav-link scrollto active" href="#hero">Home</a></li>
          <!-- <li><a class="nav-link scrollto" href="./about.html">About</a></li> -->
          <li class="dropdown"><a href="#"><span>Our products</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="./motorinsurance.php">Motor Insurance</a></li>
              <li class="dropdown"><a href="#"><span>Micro Insurance</span> <i class="bi bi-chevron-right"></i></a>
                <ul>
                  <li><a href="./hospitalcash.php">Hospital Cash</a></li>
                  <li><a href="./educate.php">Educate Protect</a></li>
                  <li><a href="./internal.php">Internal Travel</a></li>
                  <li><a href="./student.php">Student Insurance</a></li>
                </ul>
              </li>
              <li><a href="./travel.php">Travel Insurance</a></li>
              <li class="dropdown"><a href="#"><span>Personal Cover</span> <i class="bi bi-chevron-right"></i></a>
                <ul>
                  <li><a href="./personal.php">Personal Cover</a></li>
                  <li><a href="./personal.php">Group Personal Cover</a></li>
                  
                  
                </ul>
              </li>
              <li class="dropdown"><a href="#"><span>Health Insurance</span> <i class="bi bi-chevron-right"></i></a>
                <ul>
                  <li><a href="./healthcover.php">Health Insurance</a></li>
                  <li><a href="./microhealth.php">Micro Health Insurance</a></li>
              
                </ul>
              </li>
              <li><a href="./agric.php">Agricultural Cover</a></li>
            </ul>
          </li>
          <li><a class="nav-link scrollto" href="./contact.php">Contact</a></li>
          <li><a class="nav-link scrollto" href="./careers.html">Careers</a></li>
          <li><a class="nav-link scrollto" href="./policy.html">Terms and Policies</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

    </div>
  </header>