<?php
// use PHPMailer\PHPMailer\PHPMailer;
// use PHPMailer\PHPMailer\Exception;

// require 'phpmailer/src/Exception.php';
// require 'phpmailer/src/PHPMailer.php';
// require 'phpmailer/src/SMTP.php';
// echo "<script>alert('main has loaded')</script>";

// configrations
$my_smtp='smtp.gmail.com'; //your smtp eg smtp.gmail.com
$port =465;//your smtp port
$smtp_auth=true;
$smtp_secure="ssl";
$my_password ="kopxceghubezmeqz"; // your app password
$my_username ="oganga.wycliffe@bimarahisi.com"; // you username or email e.g. john@john.com
$send_to = "oganga.wycliffe@bimarahisi.com";//mail to

?>