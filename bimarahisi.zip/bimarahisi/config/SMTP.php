<?php
// configrations
$my_smtp='smtp.gmail.com'; //your smtp eg smtp.gmail.com
$port =465;//your smtp port
$smtp_auth=true;
$smtp_secure="ssl";
$my_password ="mnvfpjxahotfyvys"; // your app password
$my_username ="bismarquemomanyi@gmail.com"; // you username or email e.g. john@john.com
$send_to = "bismarquemomanyi@gmail.com";//mail to
?>
