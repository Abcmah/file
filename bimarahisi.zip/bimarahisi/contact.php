<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require './phpmailer/src/Exception.php';
require './phpmailer/src/PHPMailer.php';
require './phpmailer/src/SMTP.php';

// configrations
$my_smtp='smtp.gmail.com'; //your smtp eg smtp.gmail.com
$port =465;//your smtp port
$smtp_auth=true;
$smtp_secure="ssl";
$my_password ="kopxceghubezmeqz"; // your app password
$my_username ="oganga.wycliffe@bimarahisi.com"; // you username or email e.g. john@john.com
$send_to = "oganga.wycliffe@bimarahisi.com";//mail to


 if(isset($_POST["send"])){
    $mail = new PHPMailer(true);

    $mail->isSMTP();
    $mail->Host ='smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username =$my_username;
    $mail->Password = $my_password;
    $mail->SMTPSecure ='ssl';
    $mail->Port = 465;
    $mail->setFrom("oganga.wycliffe@bimarahisi.com");
    $mail->addAddress($my_username);
    $mail->isHTML(true);
    $mail->Subject = $_POST["email"];
    $mail->Body = "name {$_POST['name']} {$_POST['message']}";
    $mail->send();
    echo"<script> document.location.href='thankyou.html';</script>";
    exit;
 }
?>


<!DOCTYPE html>
<html lang="en">

<!-- header -->
<?php include 'include/header.php';?>
<!-- end header -->

<body>

  <!-- ======= Top Bar ======= -->
  <section id="topbar" class="d-flex align-items-center">
    <div class="container d-flex justify-content-center justify-content-md-between">
      <div class="contact-info d-flex align-items-center">
        <i class="bi bi-envelope d-flex align-items-center"><a href="mailto:info.ke@bimarahisi.com">info.ke@bimarahisi.com</a></i>
        <i class="bi bi-phone d-flex align-items-center ms-4"><span>+2547 03065065</span></i>
      </div>

      <div class="cta d-none d-md-flex align-items-center">
        <a href="#about" class="scrollto">Get a Quote</a>
      </div>
    </div>
  </section>

  <!-- ======= Header ======= -->
 <?php include 'include/navbar.php';?>
  <!-- End Header -->
 <main>
  <div class="container box d-flex">
    
  </div>
  <section style="padding: 0;" id="contact-page" class="d-flex">
    
    <div class="box-left">
      <div class="contact-form">
        <h3 style="align-self: flex-start; position: absolute;top: -5rem;" class="mb-5">Contact</h3>
         
          <form action="" method="post">
            <div>
              <label  class="my-1" for="">Name</label>
              <input  name="name" type="text" placeholder="e.g. john" class="form-control">
            </div>
            <div class="my-2">
              <label class="my-1" for="">Email</label>
              <input type="email" name="email" placeholder="example@email.com" class="form-control">
            </div>
            <div class="my-2">
              <label class="my-1" for="">Message</label>
              <textarea name="message" rows="5" class="form-control">

              </textarea>
            </div>
            <div class="mt-4">
              <button type="submit" name="send" class="btn btn-primary">Send</button>
            </div>
          </form>
        </div>
    </div>
    <div class="box-right">
      <div class="contact-info">
        <div class="contact-text">
          <p>You can also reach us by</p>
        </div>
        <div class="contact-address">
          <div class="info-box d-flex align-items-center">
            <span class="p-2 align-items-center justify-content-center">
              <i class="bx bx-map"></i>
            </span>

              <span><b>Kileleshwa, Nairobi</b></span>
          
          </div>
          <div class="info-box d-flex align-items-center ">
            <span class="p-2">
              <i class="bx bx-envelope"></i>
            </span>

              <span><b>info.ke@bimarahisi.com</b></span>
          
          </div>
          <div class="info-box d-flex align-items-center">
            <span class="p-2">
              <i class="bx bx-phone-call"></i>
            </span>

              <span><b>Kileleshwa, Nairobi</b></span>
          
          </div>
        </div>
        <div class="social-links text-lg-right pt-3 pt-lg-0 mt-3">
          <a href="#" class="twitter"><i class="bx bxl-twitter"></i></a>
          <a href="#" class="facebook"><i class="bx bxl-facebook"></i></a>
          <a href="#" class="instagram"><i class="bx bxl-instagram"></i></a>
          <a href="#" class="google-plus"><i class="bx bxl-skype"></i></a>
          <a href="#" class="linkedin"><i class="bx bxl-linkedin"></i></a>
        </div>
      </div>
  </section>
 </main>
  <!-- ======= Footer ======= -->
  <?php include 'include/footer.php';?>
  <!-- End Footer -->
</body>

</html>