// navigation/AppNavigator.js
import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import RegistrationPage from '../screens/RegistrationPage';
import LoginPage from '../screens/LoginPage';

const Stack = createStackNavigator();

const AppNavigator = () => {
  return (
    <Stack.Navigator initialRouteName="Registration">
      
      <Stack.Screen name="Registration" component={RegistrationPage} />
      <Stack.Screen name="Login" component={LoginPage} />
    </Stack.Navigator>
  );
};

export default AppNavigator;
