// screens/RegistrationPage.js
import React from 'react';
import { View, Text, TextInput, Button, StyleSheet, Alert } from 'react-native';
import { Formik } from 'formik';
import * as Yup from 'yup';

const validationSchema = Yup.object().shape({
  email: Yup.string().email('Invalid email').required('Email is required'),
  regNo: Yup.string().required('Registration Number is required'),
  department: Yup.string().required('Department is required'),
  password: Yup.string().min(6, 'Password must be at least 6 characters').required('Password is required'),
  confirmPassword: Yup.string().oneOf([Yup.ref('password'), null], 'Passwords must match').required('Confirm Password is required'),
});

const RegistrationPage = () => {
  return (
    <Formik
      initialValues={{ email: '', regNo: '', department: '', password: '', confirmPassword: '' }}
      validationSchema={validationSchema}
      onSubmit={(values) => {
        Alert.alert('Registration Successful', JSON.stringify(values, null, 2));
      }}
    >
      {({ handleChange, handleBlur, handleSubmit, values, errors, touched }) => (
        <View style={styles.container}>
          <Text style={styles.title}>Student Registration</Text>

          <TextInput
            style={styles.input}
            placeholder="Student Email"
            onChangeText={handleChange('email')}
            onBlur={handleBlur('email')}
            value={values.email}
          />
          {touched.email && errors.email && <Text style={styles.error}>{errors.email}</Text>}

          <TextInput
            style={styles.input}
            placeholder="Registration Number"
            onChangeText={handleChange('regNo')}
            onBlur={handleBlur('regNo')}
            value={values.regNo}
          />
          {touched.regNo && errors.regNo && <Text style={styles.error}>{errors.regNo}</Text>}

          <TextInput
            style={styles.input}
            placeholder="Department"
            onChangeText={handleChange('department')}
            onBlur={handleBlur('department')}
            value={values.department}
          />
          {touched.department && errors.department && <Text style={styles.error}>{errors.department}</Text>}

          <TextInput
            style={styles.input}
            placeholder="Password"
            secureTextEntry
            onChangeText={handleChange('password')}
            onBlur={handleBlur('password')}
            value={values.password}
          />
          {touched.password && errors.password && <Text style={styles.error}>{errors.password}</Text>}

          <TextInput
            style={styles.input}
            placeholder="Confirm Password"
            secureTextEntry
            onChangeText={handleChange('confirmPassword')}
            onBlur={handleBlur('confirmPassword')}
            value={values.confirmPassword}
          />
          {touched.confirmPassword && errors.confirmPassword && <Text style={styles.error}>{errors.confirmPassword}</Text>}

          <Button onPress={handleSubmit} title="Register" />
        </View>
      )}
    </Formik>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#fff',
  },
  title: {
    fontSize: 24,
    marginBottom: 20,
    textAlign: 'center',
  },
  input: {
    height: 40,
    borderColor: '#ccc',
    borderWidth: 1,
    marginBottom: 10,
    paddingHorizontal: 10,
  },
  error: {
    fontSize: 12,
    color: 'red',
  },
});

export default RegistrationPage;
