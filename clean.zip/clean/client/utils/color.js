const textColor = "#333";
const secondaryTextColor = "#828282";
const primary = "#2C7337";
const error = "#ff0000b3";
const white = "#ffffff";
const statusBar = "#0e3502";
const background = "#D9D9D9";
export default {
  textColor,
  secondaryTextColor,
  primary,
  white,
  error,
  statusBar,
  background,
};
