import { useState } from "react";
import {
  StyleSheet,
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ScrollView,
  Pressable,
  KeyboardAvoidingView,
  ActivityIndicator,
} from "react-native";
import { MaterialIcons } from "@expo/vector-icons";
import { Link, useRouter, useLocalSearchParams } from "expo-router";
import { statesOption } from "./utils/state";
import { toggleLGA } from "./utils/lga";
import {
  auth,
  createUserWithEmailAndPassword,
  updateProfile,
  setDoc,
  db,
  doc,
} from "../../firebase";
import { save } from "../../utils/helpers";
import color from "../../utils/color";

const Register = () => {
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [show, setShow] = useState(false);
  const [gender, setGender] = useState("");
  const [department, setDepartment] = useState("");
  const [errorMsg, setErrorMsg] = useState(null);
  const [loading, setLoading] = useState(false);

  const router = useRouter();
  const { nin } = useLocalSearchParams();

  const registerUser = async () => {
    setErrorMsg(null);
    const isFieldsEmpty = 
      !firstName || 
      !lastName || 
      !email || 
      !password || 
      !confirmPassword || 
      !gender || 
      !department;

    if (isFieldsEmpty) {
      setErrorMsg("All fields are required!");
      return;
    }

    if (password !== confirmPassword) {
      setErrorMsg("Your passwords do not match!");
      return;
    }

    setLoading(true);

    try {
      const userCredential = await createUserWithEmailAndPassword(auth, email, password);
      const user = userCredential.user;

      save("UserID", user.uid);

      await setDoc(doc(db, "users", user.uid), {
        firstName,
        lastName,
        email,
        gender,
        department,
        pin: "",
        imageUrl: "",
        role: "user",
        isApproved: false,
        voted: {
          "Presidential Election": false,
          "Governorship Election": false,
          "Senatorial Election": false,
          "House of Assembly Election": false,
        },
      });

      await updateProfile(user, {
        displayName: `${lastName} ${firstName}`,
      });

      setFirstName("");
      setLastName("");
      setEmail("");
      setPassword("");
      setConfirmPassword("");
      setGender("");
      setDepartment("");

      router.replace({
        pathname: "/auth/pin",
        params: { uid: user.uid },
      });
    } catch (error) {
      setErrorMsg(errorCode(error.code));
    } finally {
      setLoading(false);
    }
  };

  const errorCode = (code) => {
    switch (code) {
      case "auth/email-already-in-use":
        return "Email is already in use.";
      case "auth/invalid-email":
        return "Email is invalid.";
      case "auth/weak-password":
        return "Password should be at least 6 characters.";
      default:
        return "An unknown error has occurred.";
    }
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <KeyboardAvoidingView behavior="padding">
        <View style={styles.box}>
          <Text style={styles.title}>U-Decide</Text>
          <Text style={styles.subtitle}>Create Account</Text>

          {errorMsg && <Text style={styles.errorText}>{errorMsg}</Text>}

          <View style={styles.stack}>
            {/* Input Fields */}
            <View style={styles.inputContainer}>
              <Text style={styles.label}>First Name</Text>
              <TextInput
                style={styles.input}
                placeholder="Enter First Name"
                value={firstName}
                onChangeText={setFirstName}
              />
            </View>
            <View style={styles.inputContainer}>
              <Text style={styles.label}>Last Name</Text>
              <TextInput
                style={styles.input}
                placeholder="Enter Last Name"
                value={lastName}
                onChangeText={setLastName}
              />
            </View>
            <View style={styles.inputContainer}>
              <Text style={styles.label}>Reg No</Text>
              <TextInput
                style={styles.input}
                placeholder="Enter NIN"
                value={nin}
                editable={true}
              />
            </View>
            <View style={styles.inputContainer}>
              <Text style={styles.label}>ST Email Address</Text>
              <TextInput
                style={styles.input}
                placeholder="Enter Email Address"
                value={email}
                onChangeText={setEmail}
              />
            </View>
            <View style={styles.inputContainer}>
              <Text style={styles.label}>Password</Text>
              <View style={styles.passwordContainer}>
                <TextInput
                  style={styles.input}
                  placeholder="Enter Password"
                  secureTextEntry={!show}
                  value={password}
                  onChangeText={setPassword}
                />
                <Pressable onPress={() => setShow(!show)}>
                  <MaterialIcons
                    name={show ? "visibility" : "visibility-off"}
                    size={24}
                    color="gray"
                  />
                </Pressable>
              </View>
            </View>
            <View style={styles.inputContainer}>
              <Text style={styles.label}>Confirm Password</Text>
              <View style={styles.passwordContainer}>
                <TextInput
                  style={styles.input}
                  placeholder="Confirm Password"
                  secureTextEntry={!show}
                  value={confirmPassword}
                  onChangeText={setConfirmPassword}
                />
                <Pressable onPress={() => setShow(!show)}>
                  <MaterialIcons
                    name={show ? "visibility" : "visibility-off"}
                    size={24}
                    color="gray"
                  />
                </Pressable>
              </View>
            </View>
            <View style={styles.inputContainer}>
              <Text style={styles.label}>Gender</Text>
              <TextInput
                style={styles.input}
                placeholder="Choose Gender"
                value={gender}
                onChangeText={setGender}
                // onFocus={() => {
                //   // Show some modal or picker for gender selection
                // }}
              />
            </View>
            <View style={styles.inputContainer}>
              <Text style={styles.label}>Department</Text>
              <TextInput
                style={styles.input}
                placeholder="Choose Department"
                value={department}
                onFocus={() => {
                  // Show some modal or picker for department selection
                }}
                onChangeText={(itemValue) => {
                  setDepartment(itemValue)
                }}
              />
            </View>
          </View>

          <TouchableOpacity
            style={styles.button}
            onPress={registerUser}
            disabled={loading}
          >
            {loading ? (
              <ActivityIndicator color="#fff" />
            ) : (
              <Text style={styles.buttonText}>Create Account</Text>
            )}
          </TouchableOpacity>

          <View style={styles.footer}>
            <Text style={styles.footerText}>Already have an account?</Text>
            <Link href="/auth">
              <Text style={styles.footerLink}>Log In</Text>
            </Link>
          </View>
        </View>
      </KeyboardAvoidingView>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    padding: 16,
    backgroundColor: "#fff",
  },
  box: {
    padding: 16,
  },
  title: {
    fontFamily: "Poppins-Regular",
    color: color.primary,
    textAlign: "center",
    fontSize: 24,
  },
  subtitle: {
    fontFamily: "Poppins-Regular",
    color: color.textColor,
    textAlign: "left",
    fontSize: 20,
    marginTop: 24,
  },
  errorText: {
    marginVertical: 8,
    color: color.error,
    fontSize: 18,
    textAlign: "center",
  },
  stack: {
    marginTop: 32,
    space: 16,
  },
  inputContainer: {
    marginBottom: 16,
  },
  label: {
    fontFamily: "Poppins-Regular",
    color: color.textColor,
    textAlign: "left",
    fontSize: 16,
  },
  input: {
    fontSize: 16,
    borderColor: color.primary,
    borderWidth: 1,
    borderRadius: 4,
    padding: 8,
  },
  passwordContainer: {
    flexDirection: "row",
    alignItems: "center",
    borderColor: color.primary,
    borderWidth: 1,
    borderRadius: 4,
    padding: 8,
  },
  button: {
    marginTop: 32,
    backgroundColor: color.primary,
    padding: 16,
    borderRadius: 4,
    alignItems: "center",
  },
  buttonText: {
    fontFamily: "Poppins-Regular",
    color: "#fff",
    fontSize: 16,
  },
  footer: {
    flexDirection: "row",
    justifyContent: "center",
    marginTop: 16,
  },
  footerText: {
    fontFamily: "Poppins-Regular",
    color: color.textColor,
    fontSize: 16,
  },
  footerLink: {
    fontFamily: "Poppins-Regular",
    color: color.primary,
    fontSize: 16,
    marginLeft: 4,
  },
});

export default Register;
