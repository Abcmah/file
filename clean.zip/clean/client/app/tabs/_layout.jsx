import React from 'react';
import { StatusBar, View, StyleSheet, Dimensions } from 'react-native';
import { Tabs, useRouter } from 'expo-router';
import { Feather } from '@expo/vector-icons';
import color from '../../utils/color';
import { UserProvider, useAuth } from '../../utils/authProvider';

const { width } = Dimensions.get('window');

export default function TabLayout() {
  const { User } = useAuth();
  const router = useRouter();

  React.useEffect(() => {
    if (!User) {
      router.replace('/auth');
    }
  }, [User]);

  if (!User) {
    return null;
  }

  return (
    <UserProvider>
      <View style={{ flex: 1 }}>
        <StatusBar
          hidden={false}
          backgroundColor={color.statusBar}
          barStyle="dark-content"
        />
        <Tabs
          screenOptions={{
            headerShown: false,
            statusBarHidden: false,
            statusBarColor: color.statusBar,
            tabBarAllowFontScaling: true,
            tabBarActiveTintColor: color.primary,
            tabBarInactiveTintColor: color.secondaryTextColor,
            tabBarLabelStyle: styles.tabText,
            tabBarStyle: styles.tabStyle,
          }}
        >
          <Tabs.Screen
            name="index"
            options={{
              title: "Home",
              tabBarIcon: ({ color }) => (
                <Feather name="home" size={24} color={color} />
              ),
            }}
          />
          <Tabs.Screen
            name="vote"
            options={{
              title: "Vote",
              tabBarIcon: ({ color }) => (
                <Feather name="archive" size={24} color={color} />
              ),
            }}
          />
          <Tabs.Screen
            name="settings"
            options={{
              title: "Settings",
              tabBarIcon: ({ color }) => (
                <Feather name="settings" size={24} color={color} />
              ),
            }}
          />
        </Tabs>
      </View>
    </UserProvider>
  );
}

const styles = StyleSheet.create({
  tabText: {
    fontSize: 12,
    fontFamily: 'Poppins-Regular',
  },
  tabStyle: {
    paddingBottom: 6,
    paddingTop: 8,
    height: 64,
    width: width,
    justifyContent: 'space-around',
  },
});