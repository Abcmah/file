import React from 'react';
import { View, Text, TouchableOpacity, Image, ScrollView, StyleSheet } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import color from '../../../utils/color';
import { useAuth } from '../../../utils/authProvider';

const CandidateDetails = () => {
  const navigation = useNavigation();
  const { passedObject } = useAuth();

  // Add default values to avoid accessing undefined properties
  const { imageUrl, name, party, detail } = passedObject || {};

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.navigate('index')}>
          <View style={styles.backButton}>
            <MaterialIcons
              name="arrow-back-ios"
              size={24}
              color={color.textColor}
            />
            <Text style={styles.backText}>Back</Text>
          </View>
        </TouchableOpacity>
        <View style={styles.center}>
          <Text style={styles.title}>Electorial Candidate</Text>
        </View>
        <Text style={styles.name}>{name || 'Unknown Candidate'}</Text>
        <Text style={styles.party}>Party: {party || 'Unknown Party'}</Text>
      </View>
      <View style={styles.content}>
        <ScrollView showsVerticalScrollIndicator={false}>
          {imageUrl ? (
            <Image
              style={styles.image}
              source={{ uri: imageUrl }}
              alt="image"
            />
          ) : (
            <Text style={styles.noImageText}>No image available</Text>
          )}
          <Text style={styles.detail}>{detail || 'No details available'}</Text>
        </ScrollView>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    backgroundColor: color.white,
    padding: 16,
  },
  backButton: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  backText: {
    color: color.textColor,
    fontSize: 18,
    fontFamily: 'Poppins-Regular',
  },
  center: {
    alignItems: 'center',
    marginVertical: 16,
  },
  title: {
    color: color.textColor,
    fontSize: 24,
    fontFamily: 'Poppins-Regular',
  },
  name: {
    color: color.textColor,
    fontSize: 20,
    fontFamily: 'Poppins-Regular',
    marginTop: 16,
  },
  party: {
    color: color.secondaryTextColor,
    fontSize: 16,
    fontFamily: 'Poppins-Regular',
    marginTop: 8,
  },
  content: {
    padding: 16,
  },
  image: {
    width: '100%',
    height: 240,
    marginBottom: 16,
    borderRadius: 8,
  },
  detail: {
    color: color.textColor,
    fontSize: 16,
    fontFamily: 'Poppins-Regular',
    alignSelf: 'center',
    marginBottom: 96,
  },
  noImageText: {
    color: color.secondaryTextColor,
    fontSize: 16,
    textAlign: 'center',
    marginTop: 96, // Center text vertically within image space
  },
});

export default CandidateDetails;
