import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, ScrollView, StyleSheet, ActivityIndicator, FlatList } from 'react-native';
import { MaterialIcons, Feather } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import ResultCard from '../components/resultCard';
import { collection, query, where, getDocs, db } from '../../../firebase';
import color from '../../../utils/color';
import { numberWithCommas } from '../../../utils/helpers';

const LiveResults = () => {
  const [selected, setSelected] = useState(0);
  const [votes, setVotes] = useState(0);
  const [category, setCategory] = useState('Presidential Election');
  const [result, setResult] = useState([]);
  const [loading, setLoading] = useState(false);
  const navigation = useNavigation();

  useEffect(() => {
    setResult([]);
    setVotes(0);
    const getResult = async () => {
      setLoading(true);
      const q = query(
        collection(db, 'candidates'),
        where('category', '==', category)
      );
      const querySnapshot = await getDocs(q);
      const fetchResult = [];
      let count = 0;
      querySnapshot.forEach((doc) => {
        const fetchItem = {
          id: doc.id,
          ...doc.data(),
        };
        count = count + doc.data().vote;
        fetchResult.push(fetchItem);
      });
      setResult(fetchResult);
      setVotes(count);
      setLoading(false);
    };
    getResult();
  }, [category]);

  const handleSelected = (cat) => {
    if (cat === 'Presidential') {
      setCategory('Presidential Election');
    } else if (cat === 'Governorship') {
      setCategory('Governorship Election');
    } else if (cat === 'Senatorial') {
      setCategory('Senatorial Election');
    } else if (cat === 'House of Assembly') {
      setCategory('House of Assembly Election');
    }
  };

  const buttons = ['Presidential', 'Governorship', 'Senatorial', 'House of Assembly'];

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.navigate('vote')}>
          <View style={styles.backButton}>
            <MaterialIcons name="arrow-back-ios" size={24} color={color.textColor} />
            <Text style={styles.backText}>Back</Text>
          </View>
        </TouchableOpacity>
        <Text style={styles.title}>Live Election Results</Text>
      </View>
      <View style={styles.buttonContainer}>
        {buttons.map((buttonLabel, i) => (
          <TouchableOpacity
            key={i}
            style={[
              styles.button,
              { backgroundColor: i === selected ? color.primary : 'transparent' },
            ]}
            onPress={() => {
              setSelected(i);
              handleSelected(buttonLabel);
            }}
          >
            <Text
              style={[
                styles.buttonText,
                { color: i === selected ? color.white : color.primary },
              ]}
            >
              {buttonLabel}
            </Text>
          </TouchableOpacity>
        ))}
      </View>
      <View style={styles.infoContainer}>
        <View style={styles.infoBox}>
          <Text style={styles.infoText}>Total Votes</Text>
          <Text style={styles.infoValue}>{numberWithCommas(votes)}</Text>
        </View>
        <View style={styles.infoBox}>
          <Text style={styles.infoText}>
            <Feather name="clock" size={14} color={color.secondaryTextColor} /> voting ends
          </Text>
          <Text style={styles.infoValue}>at 11:59pm today</Text>
        </View>
      </View>
      <View style={styles.resultContainer}>
        {loading ? (
          <ActivityIndicator size="large" color={color.primary} />
        ) : (
          <FlatList
            data={result}
            renderItem={({ item }) => <ResultCard key={item.id} candidate={item} />}
            keyExtractor={(item) => item.id}
            showsVerticalScrollIndicator={false}
          />
        )}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    backgroundColor: color.white,
    padding: 16,
  },
  backButton: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  backText: {
    color: color.textColor,
    fontSize: 18,
    fontFamily: 'Poppins-Regular',
  },
  title: {
    color: color.textColor,
    fontSize: 20,
    fontFamily: 'Poppins-Regular',
    marginTop: 16,
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginVertical: 16,
  },
  button: {
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: color.primary,
  },
  buttonText: {
    fontFamily: 'Poppins-Regular',
    fontSize: 14,
  },
  infoContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginVertical: 16,
  },
  infoBox: {
    alignItems: 'center',
  },
  infoText: {
    color: color.secondaryTextColor,
    fontSize: 14,
    fontFamily: 'Poppins-Regular',
  },
  infoValue: {
    color: color.textColor,
    fontSize: 16,
    fontFamily: 'Poppins-Regular',
  },
  resultContainer: {
    flex: 1,
    paddingHorizontal: 16,
  },
});

export default LiveResults;
