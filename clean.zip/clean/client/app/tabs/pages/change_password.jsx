import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, ScrollView, StyleSheet, KeyboardAvoidingView, Platform } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import color from '../../../utils/color';
import { updatePassword } from '../../../firebase';
import { useAuth } from '../../../utils/authProvider';

const ChangePassword = () => {
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [show, setShow] = useState(false);
  const [successMsg, setSuccessMsg] = useState(null);
  const [errorMsg, setErrorMsg] = useState(null);
  const [loading, setLoading] = useState(false);

  const { currentUser } = useAuth();
  const navigation = useNavigation();

  const handleChange = () => {
    setErrorMsg(null);
    setSuccessMsg(null);
    const isFieldsEmpty = confirmPassword !== "" && password !== "";

    if (!isFieldsEmpty) {
      setErrorMsg("All fields are required!");
    } else if (confirmPassword === password) {
      setLoading(true);
      updatePassword(currentUser, password)
        .then(() => {
          setSuccessMsg("Password change was successful,\n Please remember to use it in your next login");
          setConfirmPassword("");
          setPassword("");
          setLoading(false);
        })
        .catch((error) => {
          console.log(error);
          handleErrorCode(error.code);
          setLoading(false);
        });
    } else {
      setErrorMsg("Passwords do not match");
      setLoading(false);
    }
  };

  const handleErrorCode = (code) => {
    switch (code) {
      case "auth/weak-password":
        setErrorMsg("Password should be at least 6 characters.");
        break;
      default:
        setErrorMsg("An unknown error has occurred.");
        break;
    }
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.navigate('settings')}>
          <View style={styles.backButton}>
            <MaterialIcons
              name="arrow-back-ios"
              size={24}
              color={color.textColor}
            />
            <Text style={styles.backText}>Back</Text>
          </View>
        </TouchableOpacity>
        <Text style={styles.title}>Change Password</Text>
      </View>

      {errorMsg && (
        <Text style={[styles.message, { color: color.error }]}>{errorMsg}</Text>
      )}
      {successMsg && (
        <Text style={[styles.message, { color: color.primary }]}>{successMsg}</Text>
      )}

      <ScrollView contentContainerStyle={styles.content}>
        <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : "height"}>
          <View style={styles.inputContainer}>
            <Text style={styles.label}>Enter New Password</Text>
            <View style={styles.inputWrapper}>
              <TextInput
                style={styles.input}
                secureTextEntry={!show}
                value={password}
                onChangeText={setPassword}
                placeholder="Enter new password"
              />
              <TouchableOpacity onPress={() => setShow(!show)}>
                <MaterialIcons
                  name={show ? "visibility" : "visibility-off"}
                  size={24}
                  color="gray"
                />
              </TouchableOpacity>
            </View>
          </View>
          <View style={styles.inputContainer}>
            <Text style={styles.label}>Confirm New Password</Text>
            <View style={styles.inputWrapper}>
              <TextInput
                style={styles.input}
                secureTextEntry={!show}
                value={confirmPassword}
                onChangeText={setConfirmPassword}
                placeholder="Confirm new password"
              />
              <TouchableOpacity onPress={() => setShow(!show)}>
                <MaterialIcons
                  name={show ? "visibility" : "visibility-off"}
                  size={24}
                  color="gray"
                />
              </TouchableOpacity>
            </View>
          </View>
          <TouchableOpacity
            style={[styles.button, { backgroundColor: color.primary }]}
            onPress={handleChange}
            disabled={loading}
          >
            <Text style={styles.buttonText}>
              {loading ? "Applying changes..." : "Change Password"}
            </Text>
          </TouchableOpacity>
        </KeyboardAvoidingView>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    backgroundColor: color.white,
    padding: 16,
  },
  backButton: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  backText: {
    color: color.textColor,
    fontSize: 18,
    fontFamily: 'Poppins-Regular',
  },
  title: {
    color: color.textColor,
    fontSize: 20,
    fontFamily: 'Poppins-Regular',
    marginTop: 16,
  },
  message: {
    fontFamily: 'Poppins-Regular',
    fontSize: 18,
    textAlign: 'center',
    marginVertical: 16,
  },
  content: {
    padding: 16,
  },
  inputContainer: {
    marginVertical: 8,
  },
  label: {
    fontFamily: 'Poppins-Regular',
    color: color.textColor,
    fontSize: 16,
    marginBottom: 8,
  },
  inputWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: color.primary,
    borderRadius: 8,
    paddingHorizontal: 8,
  },
  input: {
    flex: 1,
    height: 50,
    fontSize: 16,
  },
  button: {
    marginTop: 24,
    height: 50,
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
  },
  buttonText: {
    fontFamily: 'Poppins-Regular',
    color: color.white,
    fontSize: 16,
  },
});

export default ChangePassword;
