import React from 'react';
import { View, Text, ScrollView, StyleSheet, TouchableOpacity } from 'react-native';
import color from '../../utils/color';
import NewsCard from './components/newsCard';
import CandidateCards from './components/candidateCards';
import { useAuth } from '../../utils/authProvider';
import { useNavigation } from '@react-navigation/native';

const Home = () => {
  const { currentUser, candidate, news } = useAuth();
  const navigation = useNavigation();

  const goToVoteCategory = () => {
    navigation.navigate('pages/vote_category');
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerText}>
          Hello, {currentUser?.displayName}
        </Text>
      </View>

      <View style={styles.content}>
        <Text style={styles.sectionTitle}>News & Updates</Text>
        <View style={styles.newsSection}>
          {news.length > 0 ? (
            <ScrollView horizontal showsHorizontalScrollIndicator={false}>
              <View style={styles.newsContainer}>
                {news.map((item) => (
                  <NewsCard key={item.id} news={item} />
                ))}
              </View>
            </ScrollView>
          ) : (
            <ScrollView horizontal showsHorizontalScrollIndicator={false}>
              <View style={styles.newsContainer}>
                <View style={styles.skeletonBox}>
                  <View style={styles.skeletonImage} />
                  <Text style={styles.skeletonText}>Loading...</Text>
                </View>
                <View style={styles.skeletonBox}>
                  <View style={styles.skeletonImage} />
                  <Text style={styles.skeletonText}>Loading...</Text>
                </View>
              </View>
            </ScrollView>
          )}
        </View>

        <Text style={styles.sectionTitle}>Candidates</Text>
        {candidate.length > 0 ? (
          <ScrollView showsVerticalScrollIndicator={false} style={styles.scrollView}>
            <View style={styles.candidatesContainer}>
              {candidate.map((item) => (
                <CandidateCards key={item.id} candidate={item} />
              ))}
            </View>
          </ScrollView>
        ) : (
          <ScrollView showsVerticalScrollIndicator={false} style={styles.scrollView}>
            <View style={styles.candidatesContainer}>
              <View style={styles.candidateSkeleton}>
                <View style={styles.candidateSkeletonImage} />
                <View style={styles.candidateSkeletonTextContainer}>
                  <Text style={styles.candidateSkeletonText}>Loading...</Text>
                  <Text style={styles.candidateSkeletonText}>Loading...</Text>
                </View>
              </View>
              <View style={styles.candidateSkeleton}>
                <View style={styles.candidateSkeletonImage} />
                <View style={styles.candidateSkeletonTextContainer}>
                  <Text style={styles.candidateSkeletonText}>Loading...</Text>
                  <Text style={styles.candidateSkeletonText}>Loading...</Text>
                </View>
              </View>
            </View>
          </ScrollView>
        )}

        {/* Example button to navigate to VoteCategory */}
        <TouchableOpacity onPress={goToVoteCategory}>
          <Text style={styles.navigateButtonText}>Go to Vote Category</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: color.white,
  },
  header: {
    backgroundColor: color.white,
    padding: 16,
    paddingTop: 32,
  },
  headerText: {
    color: color.textColor,
    fontSize: 24,
    fontFamily: 'Poppins-Regular',
  },
  content: {
    padding: 16,
  },
  sectionTitle: {
    fontFamily: 'Poppins-Regular',
    color: color.primary,
    fontSize: 18,
  },
  newsSection: {
    marginVertical: 16,
  },
  newsContainer: {
    flexDirection: 'row',
  },
  skeletonBox: {
    width: 285,
    borderWidth: 1,
    borderColor: color.primary,
    borderRadius: 8,
    padding: 8,
    marginRight: 16,
    alignItems: 'center',
  },
  skeletonImage: {
    height: 160,
    backgroundColor: color.background,
    borderRadius: 8,
    width: '100%',
  },
  skeletonText: {
    marginTop: 8,
    color: color.secondaryTextColor,
    fontFamily: 'Poppins-Regular',
  },
  scrollView: {
    height: '48%',
  },
  candidatesContainer: {
    marginTop: 16,
  },
  candidateSkeleton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: color.white,
    padding: 16,
    borderRadius: 8,
    marginBottom: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 2,
    elevation: 2,
  },
  candidateSkeletonImage: {
    width: 84,
    height: 81,
    backgroundColor: color.background,
    borderRadius: 8,
    marginRight: 16,
  },
  candidateSkeletonTextContainer: {
    flex: 1,
  },
  candidateSkeletonText: {
    color: color.secondaryTextColor,
    fontFamily: 'Poppins-Regular',
    marginBottom: 4,
  },
  navigateButtonText: {
    marginTop: 16,
    color: color.primary,
    fontSize: 18,
    textAlign: 'center',
  },
});

export default Home;