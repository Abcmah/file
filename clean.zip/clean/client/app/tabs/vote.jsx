import React from 'react';
import { View, Text, Button, TouchableOpacity, StyleSheet, Image } from 'react-native';
import { useRouter } from 'expo-router';
import CategoryCard from './components/categoryCard';
import { useAuth } from '../../utils/authProvider';
import color from '../../utils/color';

import IMAGE from '../../utils/assets/images/no_election.png';
import ACCREDITED from '../../utils/assets/images/accredited.png';

const Vote = () => {
  const { _date, electionDate, User } = useAuth();
  const router = useRouter();
  console.log(User)
  console.log('run')
  if (User) {
    return (
      <View style={styles.container}>
        <View style={styles.header}>
          <Text style={styles.headerText}>Elections</Text>
          {_date === 0 && (
            <TouchableOpacity
              style={styles.liveResultsButton}
              onPress={() => {
                router.push('/tabs/pages/live_results');
              }}
            >
              <Text style={styles.liveResultsButtonText}>Live Results</Text>
            </TouchableOpacity>
          )}
        </View>
        <View style={styles.content}>
          {_date === 0 && (
            <View>
              <CategoryCard
                categoryName="Presidential Election"
                categoryRegion="Nationwide"
                voted={User.voted['Presidential Election']}
              />
              <CategoryCard
                categoryName="Governorship Election"
                categoryRegion="State"
                voted={User.voted['Governorship Election']}
              />
              <CategoryCard
                categoryName="Senatorial Election"
                categoryRegion="Senatorial zone"
                voted={User.voted['Senatorial Election']}
              />
              <CategoryCard
                categoryName="House of Assembly Election"
                categoryRegion="Constituency"
                voted={User.voted['House of Assembly Election']}
              />
            </View>
          )}
          {_date !== 0 && (
            <View style={styles.centeredContent}>
              <Image style={styles.image} source={IMAGE} alt="Image" />
              <Text style={styles.messageText}>
                {_date === 1 &&
                  `Election date is scheduled for the \n${new Date(electionDate).toDateString()}`}
                {_date === -1 &&
                  `Elections was held on the \n${new Date(electionDate).toDateString()}`}
              </Text>
            </View>
          )}
        </View>
      </View>
    );
  } else {
    return (
      <View style={styles.container}>
        <View style={styles.centeredContent}>
          <Image style={styles.image} source={ACCREDITED} alt="Image" />
          <Text style={styles.messageText}>
            You have not yet been accredited to vote!
          </Text>
        </View>
      </View>
    );
  }
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: color.white,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: 16,
    paddingTop: 32,
    backgroundColor: color.white,
  },
  headerText: {
    fontSize: 24,
    color: color.textColor,
    fontFamily: 'Poppins-Regular',
  },
  liveResultsButton: {
    backgroundColor: color.primary,
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 8,
  },
  liveResultsButtonText: {
    color: color.white,
    fontSize: 14,
    fontFamily: 'Poppins-Regular',
  },
  content: {
    padding: 16,
  },
  centeredContent: {
    alignItems: 'center',
    marginTop: 32,
  },
  image: {
    width: '83.33%', // 5/6 of the width
    height: 368,
  },
  messageText: {
    marginTop: 8,
    color: color.textColor,
    fontFamily: 'Poppins-Regular',
    fontSize: 20,
    textAlign: 'center',
  },
});

export default Vote;
