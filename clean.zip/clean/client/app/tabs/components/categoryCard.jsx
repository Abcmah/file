import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { Feather } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import color from '../../../utils/color';

const CategoryCard = ({ categoryName, categoryRegion, voted }) => {
  const navigation = useNavigation();

  return (
    <View style={styles.card}>
      <View style={styles.header}>
        <View>
          <Text style={styles.categoryName}>{categoryName}</Text>
          <Text style={styles.categoryRegion}>{categoryRegion}</Text>
        </View>
        <TouchableOpacity
          style={[styles.button, voted && styles.buttonDisabled]}
          onPress={() =>
            navigation.navigate('pages/vote_category')
          }
          disabled={voted}
        >
          <Text style={[styles.buttonText, voted && styles.buttonTextDisabled]}>
            {voted ? 'Voted' : 'Vote'}
          </Text>
        </TouchableOpacity>
      </View>
      <View style={styles.footer}>
        <Feather name="clock" size={14} color={color.secondaryTextColor} />
        <Text style={styles.footerText}> voting ends at 11:59pm today</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  card: {
    borderRadius: 10,
    backgroundColor: color.white,
    padding: 8,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 2,
    elevation: 5,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  categoryName: {
    fontFamily: 'Poppins-Regular',
    color: color.textColor,
    fontSize: 18,
  },
  categoryRegion: {
    fontFamily: 'Poppins-Regular',
    color: color.secondaryTextColor,
    fontSize: 14,
  },
  button: {
    borderWidth: 1,
    borderColor: color.primary,
    borderRadius: 8,
    paddingVertical: 4,
    paddingHorizontal: 12,
  },
  buttonDisabled: {
    borderColor: color.disabled,
  },
  buttonText: {
    fontFamily: 'Poppins-Regular',
    color: color.primary,
    fontSize: 16,
  },
  buttonTextDisabled: {
    color: color.disabled,
  },
  footer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 8,
  },
  footerText: {
    fontFamily: 'Poppins-Regular',
    color: color.secondaryTextColor,
    fontSize: 14,
    marginLeft: 4,
  },
});

export default CategoryCard;
