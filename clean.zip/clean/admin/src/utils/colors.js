export const colors = {
  primary: "#2C7337",
  gray: "#F2F2F2",
  grayText: "#333333",
  error: "#ff3333",
};
